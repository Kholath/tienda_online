<?php
define("IP","127.0.0.1");
define("USUARIO","tiendaonline");
define("CLAVE","tiendaonline");
define("BD","tienda");
?>